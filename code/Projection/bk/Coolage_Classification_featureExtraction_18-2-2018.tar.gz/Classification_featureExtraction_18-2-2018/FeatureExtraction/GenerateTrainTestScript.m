%% Divide dataset into two parts train and test
%% Init
basepath='~/git/Cryp-EM/Cryo-EM-Particle-Picking/code/Projection/data/';
dir= strcat(basepath,'/_pca_data-Y,Z,Neg','v.10');
datafileName= 'complete_data_coeff.txt';
testDateInPercent=25;% 25%
status= generateTrainTestDataset(dir,datafileName,testDateInPercent);

%%

