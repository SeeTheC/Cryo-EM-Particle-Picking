% dataPath: contains of paths of data where the .mat images are present
function [dataMtx,totalRecord] = getImgDataAsDataMtx(dataPath,dim)
    noOfDataDir=numel(dataPath);    
    dataMtx=[];totalRecord=0;
    for d=1:noOfDataDir
        dirPath=dataPath{d};
        [dm,recordCount]=readDatabase(dirPath,dim);
        dataMtx=vertcat(dataMtx,dm);
        totalRecord=totalRecord+recordCount;
    end
end

% Reads the images from the Database and returns the dataset Mtx where each
% row is the one record.

function [dataMtx,recordCount]=readDatabase(dirpath,dim)
    row=dim(1);col=dim(2);
    
    imgFolder = dir(dirpath);
    imgFolder =natsortfiles({imgFolder.name});     
    numOfImg=numel(imgFolder)-2;    
    numOfImg=50;
    dataMtx=zeros(numOfImg,row*col);        
    for j = 1:numOfImg
            %fileName=imgFilesPerPerson(j);fileName=fileName{1};
            fileName=imgFolder(j);
            fileName=fileName{1};
            if ( strcmp(fileName,'.') || strcmp(fileName,'..'))
                continue;
            end 
            imgPath=strcat(dirpath,'/',fileName);            
            struct=load(imgPath);
            img=struct.img;   
            %img = imread(fullFilePath);
            [irow,icol] = size(img);
            vector = reshape(img,1,irow*icol);
            %{ % duplicate check to next element
            if j>1
                isduplicate=floor(sum(dataMtx(j-1,:)==vector)/size(vector,2));           
                if isduplicate
                    continue;
                end
            end
            %}
            
            dataMtx(j,:) = vector;
    end
    recordCount=numOfImg;
    fprintf('# %d Files Read from dir %s\n',numOfImg,dirpath);
end


