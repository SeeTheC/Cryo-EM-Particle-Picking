%% Using PCA for encoding the image i.e reduction of the dimension of image

%% Init 
clear all;
basepath='~/git/Cryp-EM/Cryo-EM-Particle-Picking/code/Projection/data';
% +v images
dataPath{1}=strcat(basepath,'/Y/raw_img');
dataPath{2}=strcat(basepath,'/Z/raw_img');

%Neg images
negDataPath{1}=strcat(basepath,'/NegImg/raw_img');

% SaveDir: NOTE. CHANEGE DIR Version EVERY TIME YOU GENERATE
saveDataPath=strcat(basepath,'/_data-Y,Z,Neg','v.10');
savePCAPath=strcat(basepath,'/_pca_data-Y,Z,Neg','v.10');

%image dimension
imgHeight=333;imgWidth=333;
%% Fetch Data Images
[dataMtx,totalRecord]=getImgDataAsDataMtx(dataPath,[imgHeight,imgWidth]);

%% Finding PCA and Encoding Image Vectors
fprintf('finding PCA...');
[coeff,score,latent,tsquared,explained,mu]=pca(dataMtx);
fprintf('Done\n');
fprintf('Coeff Dim: %dx%d \n',size(coeff,1),size(coeff,2));
fprintf('mu Dim: %dx%d \n',size(mu,1),size(mu,2));
fprintf('Data Coeff Dim: %dx%d \n',size(score,1),size(score,2));

%% Save +ve data to file
fprintf('Saving Data...\n');
mkdir(saveDataPath);
dlmwrite(strcat(saveDataPath,'/positive_data.txt'),dataMtx);
% Adding classification lable
y=zeros(size(dataMtx,1),1);
y(:)=1;dataMtx=horzcat(dataMtx,y);
dlmwrite(strcat(saveDataPath,'/complete_data.txt'),dataMtx);

mkdir(savePCAPath);
dlmwrite(strcat(savePCAPath,'/pca_coeff.txt'),coeff);
dlmwrite(strcat(savePCAPath,'/data_coeff.txt'),score);
dlmwrite(strcat(savePCAPath,'/data_mean.txt'),mu);
% Adding classification lable
y=zeros(size(score,1),1);
y(:)=1;score=horzcat(score,y);
dlmwrite(strcat(savePCAPath,'/complete_data_coeff.txt'),score);

clear dataMtx;
clear score;
clear latent;
clear latent;
clear explained;
%clear coeff;
%clear mu;

fprintf('Done\n');
%% 2. Dimensionality Reduction of -ve sample using pca_coeff of +ve sample

%coeff=dlmread(strcat(savePCAPath,'/pca_coeff.txt'));
%mu=dlmread(strcat(savePCAPath,'/data_mean.txt'));
%coeff=coeff';mu=mu';

%% Fetch -ve Data Images
[dataMtx,totalRecord]=getImgDataAsDataMtx(negDataPath,[imgHeight,imgWidth]);

% Finding -ve Data Eigen Coeffient 
negData_coeff= bsxfun(@minus,dataMtx,mu)*coeff;
%% Save on to the file
dlmwrite(strcat(saveDataPath,'/negative_data.txt'),dataMtx);
dlmwrite(strcat(savePCAPath,'/negdata_coeff.txt'),negData_coeff);

% Adding classification lable
y=zeros(size(dataMtx,1),1);
y(:)=-1;dataMtx=horzcat(dataMtx,y);
dlmwrite(strcat(saveDataPath,'/complete_data.txt'),dataMtx,'-append');

y=zeros(size(negData_coeff,1),1);
y(:)=-1;negData_coeff=horzcat(negData_coeff,y);
dlmwrite(strcat(savePCAPath,'/complete_data_coeff.txt'),negData_coeff,'-append');
%%

%clear dataMtx;

