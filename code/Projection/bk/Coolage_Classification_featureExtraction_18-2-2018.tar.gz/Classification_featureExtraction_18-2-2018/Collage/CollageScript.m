%% Creates the GRID collage from dataset

%% Init
dataPath{1}='../data/Y/raw_img';
dataPath{2}='../data/Z/raw_img';

% Per cell one image
cellH=333; cellW=333;
gridRow=10; gridCol=10;
%gridRow=2; gridCol=2;

noOfCollage=300;
perDataFolderImgCount=1000;
noOfDataFolder=2;
% size of original image
%%  Test
imgPath=strcat(dataPathY,'/',num2str(1),'.mat');
struct=load(imgPath);
img=struct.img;
%%  Create Collage

 saveParentPath='../SavedFile/';
 savepath=strcat(saveParentPath,'Collage_',datestr(now,'dd-mm-yyyy HH:MM:SS')); 
 savedImgDir=strcat(savepath,'/img');
 savedRawImgDir=strcat(savepath,'/raw_img');
 
 % Creating dir
 mkdir(savepath);
 mkdir(savedImgDir);
 mkdir(savedRawImgDir);

 % Creating a file
fid = fopen(strcat(savepath,'/0_info.txt'), 'a+');
fprintf(fid, '# Angles and Number Format Matrix');
fprintf(fid, '\n# Matrix are shown in vector form where indexing is from top to bottom and left to right, similar to matlab format');

for i=1:noOfCollage
    randDataFolder=randi([1,noOfDataFolder],gridRow,gridCol);    
    randImgNum=randi([1,perDataFolderImgCount],gridRow,gridCol);
    collage=zeros(cellH*gridRow,cellW*gridCol);       
    for r=1:gridRow
        x1=(r-1)*cellH+1; x2=(r-1)*cellH+cellH;
        for c=1:gridCol
            y1=(c-1)*cellW+1; y2=(c-1)*cellW+cellW;        
            dir=randDataFolder(r,c);
            imgNum=randImgNum(r,c);
            imgPath=strcat(dataPath{dir},'/',num2str(imgNum),'.mat');
            struct=load(imgPath);
            img=struct.img;                   
            collage(x1:x2,y1:y2)=img;  
        end        
    end
    
    % writing info
    fprintf(fid, '\n# -----------------------------------\n');            
    fprintf(fid, 'Collage= %d \n',i);
    fprintf(fid, 'Folder = ');            
    fprintf(fid, ' %d',randDataFolder);
    fprintf(fid, '\nImageNumber  =');
    fprintf(fid, ' %d',randImgNum);
    imwrite(uint8(collage),strcat(savedImgDir,'/',num2str(i),'.jpg'));
    % saveing raw img
    img=collage;
    save(strcat(savedRawImgDir,'/',num2str(i),'.mat'),'img');
end
%%
figure('name','collage');
imshow(uint8(collage));
