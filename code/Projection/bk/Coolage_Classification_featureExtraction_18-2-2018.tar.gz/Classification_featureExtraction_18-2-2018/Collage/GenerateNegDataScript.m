% Generate negative samples from collage
% Negative Samples images means ovelap image
%% Init
collageDirPath='../data/Collage1/raw_img';
% Per cell one image
cellH=333; cellW=333;
gridRow=10; gridCol=10;

%  # collage in the specified folder
noOfCollage=2;
negImgPerCollage=10;
%% Generate
outputStatus  = genNegImgFromCollage(collageDirPath, ...
                                     [cellH,cellW],...
                                     [gridRow,gridCol],...
                                     noOfCollage,...
                                     negImgPerCollage);
disp(outputStatus);
%%