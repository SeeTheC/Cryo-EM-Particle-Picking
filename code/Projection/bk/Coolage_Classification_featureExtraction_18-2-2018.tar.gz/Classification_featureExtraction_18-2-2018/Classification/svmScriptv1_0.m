%% 2-Class Classification using SVM on Virus Projection Image
% Feature uses as PCA base dimensional reduction

%% INIT - Reading Data Set
clear all;
rng(1);
basepath='~/git/Cryp-EM/Cryo-EM-Particle-Picking/code/Projection/data/';
datapath= strcat(basepath,'/_pca_data-Y,Z,Neg','v.10');
trainFile= strcat(datapath,'/train.txt');
testFile= strcat(datapath,'/test.txt');

%trainFile= strcat(datapath,'/train_set1.txt');
%testFile= strcat(datapath,'/test_set1.txt');

%% Reading Train and Test dataset
trainDataSet=dlmread(trainFile);
testDataSet=dlmread(testFile);

% Separating data and label
validateSet=0.15; 
noOfTrainDataPt=size(trainDataSet,1);
validateCount=ceil(noOfTrainDataPt*validateSet);
trainDataSet=trainDataSet(1:end-validateCount,:);
validateDataSet=trainDataSet(end-validateCount+1:end,:);

trainX=trainDataSet(:,1:end-1); trainY=trainDataSet(:,end); 
clear trainDataSet;
validateX=validateDataSet(:,1:end-1); validateY=validateDataSet(:,end); 
clear validateDataSet;
testX=testDataSet(:,1:end-1); testY=testDataSet(:,end); 
clear testDataSet;

%% 1. Traing: SVM Model

svmModel = fitcsvm(trainX,trainY, ...
                    'ClassNames',{'-1','1'},... 
                    'IterationLimit',1e8,...
                    'Standardize',true);

%%              
% Extract trained, compact classifier
%compactSVMModel = compact(svmModel);
compactSVMModel = svmModel.fitPosterior();
compactSVMModel = compact(compactSVMModel);
clear svmModel;
%% Save Trained Model
save(strcat(datapath,'/compactSVMModel.mat'),'compactSVMModel');
clear compactSVMModel;
%% Load Trained Model
struct=load(strcat(datapath,'/compactSVMModel.mat'));
compactSVMModel=struct.compactSVMModel;
whos('compactSVMModel')
%%
[predLabelCell,PostProbs] = predict(compactSVMModel,validateX);

table(validateY,predLabelCell,PostProbs(:,2),'VariableNames',{'TrueLabels','PredictedLabels','PosClassPosterior'})

trueLabel=validateY;
[validateAccuracy ] = getAccuracy(trueLabel,predLabelCell);
 
fprintf('Validate Accuracy: %f\n',validateAccuracy);
%% 3. Check for Test set

[predLabelCell,PostProbs] = predict(compactSVMModel,testX);
table(testY,predLabelCell,PostProbs(:,2),'VariableNames', {'TrueLabels','PredictedLabels','PosClassPosterior'})

trueLabel=testY;
[ testAccuracy ] = getAccuracy(trueLabel,predLabelCell);
 
fprintf('Test Accuracy: %f\n',testAccuracy);
