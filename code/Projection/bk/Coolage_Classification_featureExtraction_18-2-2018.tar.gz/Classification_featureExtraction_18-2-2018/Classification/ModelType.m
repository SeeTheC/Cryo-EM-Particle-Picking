classdef ModelType
    enumeration
      CompactSVM
    end
    
    properties
    end
    
    methods
    end
    
end